package com.example.jsonreadwrite

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class JsonreadwriteApplication

fun main(args: Array<String>) {
	runApplication<JsonreadwriteApplication>(*args)
}

